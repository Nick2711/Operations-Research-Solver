﻿using System.Diagnostics;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Shared.Models;

using Solver.Engine.Core;
using Solver.Engine.IO;
using Solver.Engine.Simplex;

namespace Operation_Research_Solver.Server.Controllers; // <— adjust to your server namespace

[ApiController]
[Route("api/[controller]")]
public sealed class SolveController : ControllerBase
{
    [HttpPost]
    public ActionResult<SolveResponse> Post([FromBody] SolveRequest req, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();

        if (req is null)
            return BadRequest(new SolveResponse { OutputText = "Error: Request body is null." });

        if (string.IsNullOrWhiteSpace(req.ModelText))
            return BadRequest(new SolveResponse { OutputText = "Error: ModelText is empty." });

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        if (req.Settings?.TimeLimitSeconds is > 0)
            cts.CancelAfter(TimeSpan.FromSeconds(req.Settings.TimeLimitSeconds));
        var token = cts.Token;

        try
        {
            // Parse (use the overload your engine exposes)
            // var parsed = ModelParser.Parse(req.ModelText);
            var lines = req.ModelText.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var parsed = ModelParser.Parse(lines);

            if (parsed.Model is null)
            {
                sw.Stop();
                var fail = new StringBuilder();
                if (parsed.Log is { Count: > 0 })
                {
                    foreach (var l in parsed.Log) fail.AppendLine(l);
                }
                else
                {
                    fail.AppendLine("Failed to parse model.");
                }
                return Ok(new SolveResponse
                {
                    Success = false,
                    OutputText = fail.ToString(),
                    RuntimeMs = sw.ElapsedMilliseconds
                });
            }

            // Choose algorithm (case-insensitive)
            var alg = (req.Algorithm ?? "").Trim().ToLowerInvariant();
            ISolver solver = alg switch
            {
                "primal simplex" or "primal" => new PrimalSimplexSolver(),
                "revised simplex" or "revised" => new RevisedSimplexSolverStub(), // replace when ready
                _ => new PrimalSimplexSolver()
            };

            token.ThrowIfCancellationRequested();

            var result = solver.Solve(parsed.Model);

            token.ThrowIfCancellationRequested();

            // Build output: canonical + iterations/log
            var outText = new StringBuilder();

            // If your ParseResult exposes canonical text, include it (rename if your property differs)
            if (!string.IsNullOrWhiteSpace(parsed.CanonicalAsText))
            {
                outText.AppendLine("=== Canonical Form ===");
                outText.AppendLine(parsed.CanonicalAsText);
                outText.AppendLine();
            }

            outText.AppendLine($"Algorithm: {solver.Name}");
            var linesToShow = req.Settings?.Verbose == true ? result.Log : result.Log?.Take(10) ?? Enumerable.Empty<string>();
            foreach (var l in linesToShow) outText.AppendLine(l);

            if (result.Success)
            {
                outText.AppendLine();
                outText.AppendLine($"SUCCESS — Objective: {result.ObjectiveValue:0.###}");
                if (result.X is { Length: > 0 })
                    outText.AppendLine("Solution: " + string.Join(", ", result.X.Select((v, i) => $"x{i + 1}={v:0.###}")));
            }
            else
            {
                outText.AppendLine();
                outText.AppendLine(result.Unbounded ? "FAILED — Unbounded."
                                 : result.Infeasible ? "FAILED — Infeasible (Phase I needed)."
                                 : "FAILED — Unknown.");
            }

            sw.Stop();

            return Ok(new SolveResponse
            {
                Success = result.Success,
                Unbounded = result.Unbounded,
                Infeasible = result.Infeasible,
                Objective = result.Success ? Math.Round(result.ObjectiveValue, 3) : null,
                SolutionSummary = result.Success && result.X is { Length: > 0 }
                                  ? string.Join(", ", result.X.Select((v, i) => $"x{i + 1}={v:0.###}"))
                                  : null,
                OutputText = outText.ToString(),
                RuntimeMs = sw.ElapsedMilliseconds
            });
        }
        catch (OperationCanceledException)
        {
            sw.Stop();
            return StatusCode(408, new SolveResponse { OutputText = "Timed out.", RuntimeMs = sw.ElapsedMilliseconds });
        }
        catch (Exception ex)
        {
            sw.Stop();
            return BadRequest(new SolveResponse { OutputText = $"Error: {ex.Message}", RuntimeMs = sw.ElapsedMilliseconds });
        }
    }
}
