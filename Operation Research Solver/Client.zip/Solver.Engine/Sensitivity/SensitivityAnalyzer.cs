// Solver.Engine/Sensitivity/SensitivityAnalyzer.cs
namespace Solver.Engine.Sensitivity;
public sealed class SensitivityAnalyzer
{
    // TODO: ranges, shadow prices, post-opt analysis
}


