// Solver.Engine/Integer/BranchAndBound.cs
namespace Solver.Engine.Integer;
public sealed class BranchAndBound
{
    // TODO: generic B&B framework
}


