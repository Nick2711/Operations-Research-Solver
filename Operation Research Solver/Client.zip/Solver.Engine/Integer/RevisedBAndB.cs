// Solver.Engine/Integer/RevisedBB.cs
namespace Solver.Engine.Integer;
public sealed class RevisedBAndB
{
    // TODO: revised simplex-based B&B
}


