// Solver.Engine/Integer/KnapsackBnB.cs
namespace Solver.Engine.Integer;
public sealed class KnapsackBAndB
{
    // TODO: dedicated 0-1 knapsack B&B
}


