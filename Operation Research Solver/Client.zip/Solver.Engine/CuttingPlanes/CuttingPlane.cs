// Solver.Engine/CuttingPlanes/RevisedCuttingPlane.cs
namespace Solver.Engine.CuttingPlanes;
public sealed class CuttingPlane
{
    // TODO: implement Gomory (revised) later
}


