// Solver.Engine/CuttingPlanes/RevisedCuttingPlane.cs
namespace Solver.Engine.CuttingPlanes;
public sealed class RevisedCuttingPlane
{
    // TODO: implement Gomory (revised) later
}


