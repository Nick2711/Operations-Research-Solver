// Solver.Engine/Utils/Matrix.cs
namespace Solver.Engine.Utils;

public static class Matrix
{
    // add helpers later; keep empty so build passes
}


