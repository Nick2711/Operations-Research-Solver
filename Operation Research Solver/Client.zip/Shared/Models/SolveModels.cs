﻿// Shared/Models/SolveModels.cs
using System.Text.Json.Serialization;

namespace Shared.Models;

[JsonConverter(typeof(JsonStringEnumConverter))] // serialize enum <-> "PrimalSimplex" etc.
public enum Algorithm
{
    PrimalSimplex,
    RevisedSimplex,
    BranchAndBoundSimplex,
    CuttingPlane,
    KnapsackBnB
}

public sealed class SolveRequest
{
    public Algorithm Algorithm { get; set; } = Algorithm.PrimalSimplex;
    public string ModelText { get; set; } = "";
    public SolveSettings Settings { get; set; } = new();
}

public sealed class SolveSettings
{
    public int MaxIterations { get; set; } = 5000;   // simplex / revised
    public int MaxNodes { get; set; } = 2000;        // B&B later
    public bool Verbose { get; set; } = true;        // include tableau/log lines
    public int TimeLimitSeconds { get; set; } = 60;  // server-side guardrail
}

public sealed class SolveResponse
{
    // Status
    public bool Success { get; set; }
    public bool Unbounded { get; set; }
    public bool Infeasible { get; set; }

    // Solution
    public double? Objective { get; set; }           // rounded to 3 dp by server
    public double[] X { get; set; } = Array.Empty<double>(); // variable values (x1..xn)

    // Logging / display
    public List<string> Log { get; set; } = new();   // canonical form + iterations
    public string OutputText { get; set; } = "";     // optional: preformatted block if you want

    // Metadata
    public string? SolutionSummary { get; set; }
    public long RuntimeMs { get; set; }
}
