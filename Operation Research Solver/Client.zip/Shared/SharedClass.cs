/* Shared classes can be referenced by both the Client and Server */
